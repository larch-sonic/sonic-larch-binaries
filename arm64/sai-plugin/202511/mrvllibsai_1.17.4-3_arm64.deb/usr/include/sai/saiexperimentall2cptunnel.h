/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentall2cptunnel.h
 *
 * @brief   This module defines SAI extensions for L2CP tunneling
 *
 * @warning This module is a SAI experimental module.
 */

#if !defined (__SAIEXPERIMENTALL2CPTUNNEL_H_)
#define __SAIEXPERIMENTALL2CPTUNNEL_H_

#include <saitypes.h>

/**
 * @defgroup SAIL2CPTUNNEL SAI - Experimental: L2CP Tunnel specific API definitions
 *
 * @{
 */

/**
 * @brief Attribute ID for L2CP tunnel
 */
typedef enum _sai_l2cp_tunnel_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_L2CP_TUNNEL_ATTR_START,

    /**
     * @brief Port on which to apply L2CP MAC rewrite
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_L2CP_TUNNEL_ATTR_PORT = SAI_L2CP_TUNNEL_ATTR_START,

    /**
     * @brief Original L2CP protocol destination MAC to match
     *
     * @type sai_mac_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_L2CP_TUNNEL_ATTR_PROTOCOL_MAC,

    /**
     * @brief Tunnel MAC to rewrite matched frames' destination MAC to
     *
     * @type sai_mac_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_L2CP_TUNNEL_ATTR_TUNNEL_MAC,

    /**
     * @brief End of attributes
     */
    SAI_L2CP_TUNNEL_ATTR_END,

    /** Custom range base value */
    SAI_L2CP_TUNNEL_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_L2CP_TUNNEL_ATTR_CUSTOM_RANGE_END,

} sai_l2cp_tunnel_attr_t;

/**
 * @brief Create L2CP tunnel
 *
 * @param[out] l2cp_tunnel_id L2CP tunnel id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
typedef sai_status_t (*sai_create_l2cp_tunnel_fn)(
        _Out_ sai_object_id_t *l2cp_tunnel_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove L2CP tunnel
 *
 * @param[in] l2cp_tunnel_id L2CP tunnel id
 *
 * @return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
typedef sai_status_t (*sai_remove_l2cp_tunnel_fn)(
        _In_ sai_object_id_t l2cp_tunnel_id);

/**
 * @brief Set attribute for L2CP tunnel
 *
 * @param[in] l2cp_tunnel_id L2CP tunnel id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
typedef sai_status_t (*sai_set_l2cp_tunnel_attribute_fn)(
        _In_ sai_object_id_t l2cp_tunnel_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get attribute for L2CP tunnel
 *
 * @param[in] l2cp_tunnel_id L2CP tunnel id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success Failure status code on error
 */
typedef sai_status_t (*sai_get_l2cp_tunnel_attribute_fn)(
        _In_ sai_object_id_t l2cp_tunnel_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief L2CP tunnel method table retrieved with sai_api_query()
 */
typedef struct _sai_l2cp_tunnel_api_t
{
    sai_create_l2cp_tunnel_fn            create_l2cp_tunnel;
    sai_remove_l2cp_tunnel_fn            remove_l2cp_tunnel;
    sai_set_l2cp_tunnel_attribute_fn     set_l2cp_tunnel_attribute;
    sai_get_l2cp_tunnel_attribute_fn     get_l2cp_tunnel_attribute;

} sai_l2cp_tunnel_api_t;

/**
 * @}
 */
#endif /** __SAIEXPERIMENTALL2CPTUNNEL_H_ */
